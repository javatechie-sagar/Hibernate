import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SecondLevelCacheDemo {

    public static void main(String[] args) {
    	
        SessionFactory sf =
            new Configuration().configure().buildSessionFactory();
      
        // SESSION 1
        Session session1 = sf.openSession();
        Employee e1 = session1.get(Employee.class, 101);
        System.out.println("Session1: " + e1.getEmpName());
        session1.close();
        
        // Second Level Cache
        // SESSION 2 - Separate cache
        Session session2 = sf.openSession();
        Employee e2 = session2.get(Employee.class, 101);
        System.out.println("Session2: - By 2nd Level Cache" + e2.getEmpName());
        session2.close();
        sf.close();
    }
}
