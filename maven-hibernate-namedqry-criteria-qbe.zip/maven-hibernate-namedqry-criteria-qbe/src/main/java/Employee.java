import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
// Named query
@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findempbyname",  
	        query = "from Employee e where e.empName = :empName" 
	        ) ,
	        @NamedQuery(  
	    	        name = "findempbysal",  
	    	        query = "from Employee e where e.salary >= :salary" 
	    	        )  
	    }  
	)  
// 
@Entity
@Table(name = "employee")
public class Employee   implements Serializable{
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "empId")
	int empId;
	@Column(name = "empName")
	String empName;
	@Column(name = "salary")
	int salary;
	

	public Employee() {
	}
	public Employee(int empId, String empName, int salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

		public int getSalary() {
		return salary;
	}
		@Override
		public String toString() {
			return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + "]";
		}
}