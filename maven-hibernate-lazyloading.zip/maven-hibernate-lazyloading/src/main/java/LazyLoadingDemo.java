import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class LazyLoadingDemo {

    public static void main(String[] args) {
        // Create SessionFactory
        SessionFactory sf = new Configuration().configure().buildSessionFactory();
        // Open session
        Session session = sf.openSession();
        // Fetch Employee (ONLY employee table hit)
        Employee emp = session.get(Employee.class, 101);
        // No extra SQL
        System.out.println("Employee Name: " + emp.getEmpName());
        System.out.println("Salary: " + emp.getSalary());
        // LAZY loading happens here
		System.out.println("Department Name: " + 
        emp.getDepartment().getDeptName() + "-- Fetched by Lazy Loading!") ;
        // Close session
        session.close();
        sf.close();
    }
}
