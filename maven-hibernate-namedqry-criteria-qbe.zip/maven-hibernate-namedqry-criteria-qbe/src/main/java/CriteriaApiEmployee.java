
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
.import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class CriteriaApiEmployee {
	public static void main(String[] args) {
		Session session = null;
		System.out.println("Before creating session factory object");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		System.out.println("Factory object created ... before opening session");
		session = sessionFactory.openSession();
		System.out.println("Reading Rows");
		Transaction tran = session.beginTransaction();
		/* READ all the employees having salary 
		 * more than   70000 */
		// Create Criteria object
		Criteria cr = session.createCriteria(Employee.class);
		// Add restriction.
		cr.add(Restrictions.gt("salary", 70000));
		List<Employee> empList = cr.list();
		System.out.println("Employee Details - Criteria query sal>70000 : ");
		for (Employee emp : empList) {
			System.out.print("Id : " + emp.getEmpId());
			System.out.print("\tName: " + emp.getEmpName());
			System.out.println("\tSalary: " + emp.getSalary());
		}
		
		

		System.out.println("------------------------------------------------");

		// Get Total Salary
		System.out.println("Projections - Like group functions - sum, min, max: ");
		cr = session.createCriteria(Employee.class);

		// To get total salary.
		cr.setProjection(Projections.sum("salary"));
		List totalSalary = cr.list();
		System.out.println("Total Salary: " + totalSalary.get(0));

		// To get maximum of a property.
		cr.setProjection(Projections.max("salary"));
		List maxSalary = cr.list();
		System.out.println("Max Salary: " + maxSalary.get(0));

		// To get minimum of a property.
		cr.setProjection(Projections.min("salary"));
		List minSalary = cr.list();
		System.out.println("Min Salary: " + minSalary.get(0));
	}
}
		