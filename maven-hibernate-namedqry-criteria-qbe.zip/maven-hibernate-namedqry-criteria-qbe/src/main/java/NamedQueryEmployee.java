
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class NamedQueryEmployee {
	public static void main(String[] args) {
		Session session = null;
		try {
			System.out.println("Before creating session factory object");
			SessionFactory sessionFactory = 
					new Configuration().configure().buildSessionFactory();
			System.out.println("factory object created ... before opening session");
			session = sessionFactory.openSession();
			System.out.println("Reading Rows");
			session.beginTransaction();		
			
			List<Employee> empByNameList = 
					session.getNamedQuery("findempbyname")
								.setParameter("empName", "Nesha")
								.list();
			
			System.out.println("Number of rows : " + empByNameList.size());
			System.out.println("Employee Information By Name - named query");
			for (Employee emp : empByNameList) {
				System.out.println(emp.getEmpId() + "  " + emp.getEmpName());
			}
			List<Employee> empBySalList = 
					session.getNamedQuery("findempbysal")
					.setParameter("salary", 80000)
					.list();
			System.out.println("Number of rows : " + empBySalList.size());
			System.out.println("Employee Informaion by Salary  - named query");
			for (Employee emp : empBySalList) {
				System.out.println(emp.getEmpId() + "  " + emp.getEmpName() + " " + emp.getSalary());
			}
			System.out.println("Done");
						
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				session.flush();
				session.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}